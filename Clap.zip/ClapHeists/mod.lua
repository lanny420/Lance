local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_jolly" and "AfterClap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end
 
local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_wwh" and "Alaskan Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_gallery" and "Clap Gallery"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_branchbank_deposit" and "Bank Clap: Deposit"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_branchbank_cash" and "Bank Clap: Cash"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_branchbank" and "Bank Clap: Random"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_branchbank_gold" and "Bank Clap: Gold"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_pbr" and "Beneath the Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_welcome_to_the_jungle" and "Clap Oil"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_pbr2" and "Birth of Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_mad" and "Boiling Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_spa" and "Brookly Clap-Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_cage" and "Clap Shop"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_rat" and "Clap Off"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_pal" and "CounterClap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_election_day" and "Election Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_firestarter" and "ClapStarter"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_red2" and "First World Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_four_stores" and "Four Claps"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_framing_frame" and "Framing Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_roberts" and "GO Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_peta" and "Clap Simulator"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_kenaz_full" and "Golden Clap Casino"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_glace" and "Green Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_run" and "Clap Street"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_mia" and "Hotline Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_hox" and "Clap Breakout"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_hox_3" and "Clap Revenge"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_jewelry_store" and "Jewelry Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_nail" and "Lab Claps"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_mallcrasher" and "MallClapper"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_shoutout_raid" and "ClapDown"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_dark" and "Clap Station"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_nightclub" and "Night Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_flat" and "Clap Room"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_help" and "Prison ClapMare"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_alex" and "Claps"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_chill_combat" and "Safe House Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_cane" and "Santa´s ClapShop"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_friend" and "ClapFace Mansion"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_kosugi" and "Shadow Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_dinner" and "SlaughterClap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_moon" and "Stealing ClapMas"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_arena" and "The Alesso Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_big" and "Big Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_born" and "The Biker Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_crojob1" and "The Clap: Dockyard"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_crojob" and "The Clap: Forest"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_fish" and "The Yacht Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)
end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_ukranian_job" and "Ukranian Clap"

or testAllStrings == true and string_id
or text_original(self, string_id, ...)

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_man" and "UnderClapper"

end
local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_watchdogs" and "Watch Claps"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_pines" and "White ClapMas"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_haunted" and "Clap House Nightmare"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_hvh" and "Clapped Kill Room"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_rvd" and "Reservoir Claps"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_dah" and "Diamond Clap"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_tag" and "Breaking Claps"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_brb" and "Brookly Clap"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_bph" and "Hell´s Clap"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_des" and "Henry´s Clap"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_nmh" and "No Clap"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_sah" and "Shacklethorne Claption"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_mus" and "The Clap"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_vit" and "The White Clap"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_arm_for" and "Clap: Train Heist"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_arm_cro" and "Clap: Crossroads"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_hmc" and "Clap: Downtown"

end

local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_fac" and "Clap: Harbor"

end


local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_par" and "Clap: Park"

end


local text_original = LocalizationManager.text
local testAllStrings = false  --Set to true to show all string ID's, false to return to normal.
function LocalizationManager:text(string_id, ...)
return string_id == "heist_und" and "Clap: Underpass"

end